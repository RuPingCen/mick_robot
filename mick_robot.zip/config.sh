sudo apt-get install ros-kinetic-serial ros-kinetic-amcl ros-kinetic-map-server ros-kinetic-gmapping ros-kinetic-move-base
    
sudo apt-get install ros-kinetic-tf*

sudo apt-get install libpcap-dev
