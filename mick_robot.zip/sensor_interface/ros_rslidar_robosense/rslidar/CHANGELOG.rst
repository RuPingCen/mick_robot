Change history
==============

1.0.0 (2017-06-22): first release for mutil node version
