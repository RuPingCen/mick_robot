sudo apt-get install vim 
sudo apt-get install htop 
sudo apt-get install terminator
sudo apt-get install openssh-*
sudo apt-get install ros-kinetic-gmapping
sudo apt-get install ros-kinetic-amcl
sudo apt-get install ros-kinetic-map-server
sudo apt-get install ros-kinetic-move-base
sudo apt-get install ros-kinetic-global-planner
sudo apt-get install ros-kinetic-base-local-planner
sudo apt-get install ros-kinetic-dwa-local-planner
sudo apt-get install ros-kinetic-rosbridge-*
sudo apt-get install ros-kinetic-serial

